# aldo

The idea for this assignment was to practice getting the robots to follow each other. By using the transform and tf2, the turtle would have know the locations of the other robots
and been able to head to that location thanks to the math that was available. In my case, this did not work for the second turtle as there must have been an error somewhere in 
the code because it seems as though the spawn function did not work properly cause the process to die. I managed to get the robot visible on in the same environment but it did not 
respond further. I'm going to work with August to understand what I did wrong. While I am submitting this after the grace day period, I stopped coding around 11:55. My normal 
methods of sumbission weren't working, it finally cooperated this morning after class. 
